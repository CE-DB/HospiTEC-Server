﻿using Microsoft.AspNetCore.Mvc;


// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace HospiTec_Server.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class ReportController : Controller
    {
        public IActionResult Index()
        {
            return null;
        }

    }
}
